$!/bin/bash
mkdir /home/ubuntu/environment/noderedvol || true && sudo chown -R 1000:1000 /home/ubuntu/environment/noderedvol